package com.example.makanannusantara

import android.support.v7.view.menu.MenuView
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView

class ListFoodAdapter(private  val listFood: ArrayList<Food>): RecyclerView.Adapter<ListFoodAdapter.ListViewHolder>() {

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): ListViewHolder {
        val view: View = LayoutInflater.from(p0.context).inflate(R.layout.item_row_food,p0,false)
        return  ListViewHolder(view)
    }

    override fun onBindViewHolder(p0: ListViewHolder, p1: Int) {
        val(name, description, photo)= listFood[p1]
        p0.imgPhoto.setImageResource(photo)
        p0.tvName.text = name
        p0.tvDescription.text = description
    }

    override fun getItemCount(): Int = listFood.size
    class ListViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        val imgPhoto: ImageView = itemView.findViewById(R.id.img_item_photo)
        val tvName: TextView = itemView.findViewById(R.id.tv_item_name)
        val tvDescription: TextView = itemView.findViewById(R.id.tv_item_description)
    }
}